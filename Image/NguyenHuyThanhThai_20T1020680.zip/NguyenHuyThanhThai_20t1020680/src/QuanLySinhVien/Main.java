package QuanLySinhVien;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

public class Main {
	private static final Scanner sc = new Scanner(System.in);
	private static final DanhSachSinhVien dssv = new DanhSachSinhVien();

	public static void main(String[] args) {
		while (true) {
			inMenu();
			int chon = nhapSoNguyen("Chon chuc nang: ");
			switch (chon) {
			case 1 -> themSinhVien();
			case 2 -> xoaSinhVien();
			case 3 -> timKiemTheoTen();
			case 4 -> hienThiDanhSach();
			case 5 -> locSinhVien();
			case 6 -> thongKe();
			case 7 -> luuFile();
			case 8 -> docFile();
			case 9 -> {
				System.out.println("Tam biet!");
				return;
			}
			default -> System.out.println("Lua chon khong hop le.");
			}
			System.out.println();
		}
	}

	private static void inMenu() {
		System.out.println("===== QUAN LY SINH VIEN =====");
		System.out.println("1. Them sinh vien");
		System.out.println("2. Xoa sinh vien");
		System.out.println("3. Tim kiem sinh vien theo ten");
		System.out.println("4. Hien thi danh sach sinh vien");
		System.out.println("5. Loc sinh vien theo ket qua hoc tap");
		System.out.println("6. Thong ke so luong sinh vien Dat / Khong dat");
		System.out.println("7. Luu danh sach ra file");
		System.out.println("8. Doc danh sach tu file");
		System.out.println("9. Thoat");
	}

	private static int nhapSoNguyen(String msg) {
		while (true) {
			System.out.print(msg);
			try {
				return Integer.parseInt(sc.nextLine().trim());
			} catch (Exception e) {
				System.out.println("Vui long nhap so hop le.");
			}
		}
	}

	private static double nhapSoThuc(String msg) {
		while (true) {
			System.out.print(msg);
			try {
				return Double.parseDouble(sc.nextLine().trim());
			} catch (Exception e) {
				System.out.println("Vui long nhap so thuc hop le (vd 7.5).");
			}
		}
	}

	private static void themSinhVien() {
		System.out.print("Ma SV: ");
		String ma = sc.nextLine().trim();
		System.out.print("Ho ten: ");
		String ten = sc.nextLine().trim();
		System.out.print("Gioi tinh (Nam/Nu): ");
		String gt = sc.nextLine().trim();
		System.out.print("Que quan: ");
		String qq = sc.nextLine().trim();
		double dtb = nhapSoThuc("Diem TB: ");
		dssv.them(new SinhVien(ma, ten, gt, qq, dtb));
		System.out.println("Da them.");
	}

	private static void xoaSinhVien() {
		System.out.print("Nhap ma SV can xoa: ");
		String ma = sc.nextLine().trim();
		boolean ok = dssv.xoaTheoMa(ma);
		System.out.println(ok ? "Da xoa." : "Khong tim thay ma SV.");
	}

	private static void timKiemTheoTen() {
		System.out.print("Nhap ten hoac tu khoa: ");
		String ten = sc.nextLine().trim();
		List<SinhVien> kq = dssv.timTheoTen(ten);
		if (kq.isEmpty())
			System.out.println("Khong co ket qua.");
		else
			for (SinhVien sv : kq)
				System.out.println(sv);
	}

	private static void hienThiDanhSach() {
		List<SinhVien> all = dssv.hienThiTatCa();
		if (all.isEmpty())
			System.out.println("Danh sach rong.");
		else
			for (SinhVien sv : all)
				System.out.println(sv);
	}

	private static void locSinhVien() {
		System.out.println("1. Dat (diemTB >= 5.0)");
		System.out.println("2. Khong dat (diemTB < 5.0)");
		int c = nhapSoNguyen("Chon: ");
		List<SinhVien> kq = (c == 1) ? dssv.locDat() : dssv.locKhongDat();
		if (kq.isEmpty())
			System.out.println("Khong co sinh vien phu hop.");
		else
			for (SinhVien sv : kq)
				System.out.println(sv);
	}

	private static void thongKe() {
		int[] t = dssv.thongKeDatKhongDat();
		System.out.println("Dat: " + t[0] + ", Khong dat: " + t[1]);
	}

	private static void luuFile() {
		System.out.print("Nhap duong dan file (vd sinhvien.txt): ");
		String path = sc.nextLine().trim();
		try {
			dssv.luuRaFile(path);
			System.out.println("Da luu vao: " + path);
		} catch (IOException e) {
			System.out.println("Loi luu file: " + e.getMessage());
		}
	}

	private static void docFile() {
		System.out.print("Nhap duong dan file (vd sinhvien.txt): ");
		String path = sc.nextLine().trim();
		try {
			dssv.docTuFile(path);
			System.out.println("Da doc xong.");
		} catch (IOException e) {
			System.out.println("Loi doc file: " + e.getMessage());
		}
	}
}
