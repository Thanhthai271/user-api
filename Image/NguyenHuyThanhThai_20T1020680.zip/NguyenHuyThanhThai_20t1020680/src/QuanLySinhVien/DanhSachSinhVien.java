package QuanLySinhVien;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DanhSachSinhVien {
	private final ArrayList<SinhVien> ds = new ArrayList<>();

	public void them(SinhVien sv) {
		ds.add(sv);
	}

	public boolean xoaTheoMa(String ma) {
		return ds.removeIf(sv -> sv.getMaSV().equalsIgnoreCase(ma));
	}

	public List<SinhVien> timTheoTen(String ten) {
		String key = ten.toLowerCase(Locale.forLanguageTag("vi"));
		ArrayList<SinhVien> kq = new ArrayList<>();
		for (SinhVien sv : ds) {
			if (sv.getHoTen().toLowerCase(Locale.forLanguageTag("vi")).contains(key))
				kq.add(sv);
		}
		return kq;
	}

	public List<SinhVien> hienThiTatCa() {
		return new ArrayList<>(ds);
	}

	public List<SinhVien> locDat() {
		ArrayList<SinhVien> kq = new ArrayList<>();
		for (SinhVien sv : ds)
			if (sv.getDiemTB() >= 5.0)
				kq.add(sv);
		return kq;
	}

	public List<SinhVien> locKhongDat() {
		ArrayList<SinhVien> kq = new ArrayList<>();
		for (SinhVien sv : ds)
			if (sv.getDiemTB() < 5.0)
				kq.add(sv);
		return kq;
	}

	public int[] thongKeDatKhongDat() {
		int dat = 0, khongDat = 0;
		for (SinhVien sv : ds) {
			if (sv.getDiemTB() >= 5.0)
				dat++;
			else
				khongDat++;
		}
		return new int[] { dat, khongDat };
	}

	public void luuRaFile(String filePath) throws IOException {
		Path p = Paths.get(filePath);
		ArrayList<String> lines = new ArrayList<>();
		for (SinhVien sv : ds)
			lines.add(sv.toString());
		Files.write(p, lines, StandardCharsets.UTF_8);
	}

	public void docTuFile(String filePath) throws IOException {
		Path p = Paths.get(filePath);
		if (!Files.exists(p))
			return;
		List<String> lines = Files.readAllLines(p, StandardCharsets.UTF_8);
		ds.clear();
		for (String line : lines) {
			String[] parts = line.split(";");
			if (parts.length == 5) {
				String ma = parts[0].trim();
				String ten = parts[1].trim();
				String gt = parts[2].trim();
				String qq = parts[3].trim();
				double dtb;
				try {
					dtb = Double.parseDouble(parts[4].trim());
				} catch (NumberFormatException e) {
					continue;
				}
				ds.add(new SinhVien(ma, ten, gt, qq, dtb));
			}
		}
	}
}
